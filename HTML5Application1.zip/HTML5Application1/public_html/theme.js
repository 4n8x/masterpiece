function theme() {
    var currentTheme = localStorage.getItem('theme');
    if (currentTheme == 'red') {
        localStorage.setItem("theme", 'blue');
        document.documentElement.className = 'blue';
    } else {
        localStorage.setItem("theme", 'red');
        document.documentElement.className = 'red';
    }
}

window.onload = function() {
    if (localStorage.getItem('theme') == 'red') {
        document.documentElement.className = 'red';
    } else {
        document.documentElement.className = 'blue';
    }
}

function showStore(store) {
    var el = document.getElementsByClassName('show-store-' + store);

    for (var i = 0; i < el.length; i++) {
        if (el[i].style.display == "table-cell")
            el[i].style.display = "none";
        else
            el[i].style.display = "table-cell";
    }
}