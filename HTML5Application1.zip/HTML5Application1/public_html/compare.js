var product = [{
"id":0,
"title":"",
"price":"",
"image" : "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-placeholder.svg/1665px-No-Image-Placeholder.svg.png"
},{
"id" : 1,
"title" :"Self-Portrait by vanGogh",
"price" : "$15.00",

"image" : "p1.jpg" 

},{
"id" : 2,
"title" :"The Girl With Pearl Earring",
"price" : "$20,00",

"image" :"P2.jpg"
},
{
"id" : 3,
"title" :"Woman In Hat And Fur Collar",
"price" :"$10,00",

"image" :"P3.jpg"
},

{
"id" : 4,
"title" :"The Water Lily Pond",
"price" : "$25,00",

"image" :"P4.jpg"
},

{
"id" : 5,
"title" :"Starry Night Over The Rhone",
"price" : "$30,00",

"image" :"P5.jpg"
},
{
"id" : 6,
"title" :"The Persistence Of Memory",
"price" :"$35,00",

"image" :"P6.jpg"
},

{
"id" : 7,
"title" :"Creativity",
"price" : "$70,00",

"image" :"SC1.jpg"
},
{
"id" : 8,
"title" :"The meaning of meditation",
"price" :"$75,00",

"image" :"SC2.jpg"
},

{
"id" : 9,
"title" :"The inner space",
"price" : "$80,00",

"image" :"SC3.jpg"
},

{
"id" : 10,
"title" :"Child innocence",
"price" : "$85,00",

"image" :"SC4.jpg"
},

{
"id" : 11,
"title" :"Me myself & I",
"price" : "$90,00",

"image" :"SC5.jpg"
},

{
"id" : 12,
"title" :"The meaning of sadness",
"price" : "$95,00",

"image" :"SC6.jpg"
}
]